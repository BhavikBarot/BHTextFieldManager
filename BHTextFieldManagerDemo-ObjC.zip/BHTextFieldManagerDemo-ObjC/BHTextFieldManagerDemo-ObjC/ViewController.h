//
//  ViewController.h
//  BHTextFieldManagerDemo-ObjC
//
//  Created by Bhavik's Mac on 5/7/18.
//  Copyright © 2018 Bhavik Barot. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <BHTextFieldManager/BHTextFieldManager.h>

@interface ViewController : UIViewController<UITextFieldDelegate,UITextViewDelegate,BHTextFieldManagerAccesoryViewDelegate>
{
    IBOutlet UIView *mainView1;
    IBOutlet UIView *mainView2;
    IBOutlet UIView *mainView3;
    IBOutlet UIView *mainView4;
    IBOutlet UIView *mainView5;
    IBOutlet UIView *mainView6;
    IBOutlet UIView *mainView7;
    
    IBOutlet UITextView *textview;
}
@end

