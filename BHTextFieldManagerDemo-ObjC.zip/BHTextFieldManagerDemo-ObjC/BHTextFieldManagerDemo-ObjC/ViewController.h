//
//  ViewController.h
//  BHTextFieldManagerDemo-ObjC
//
//  Created by Bhavik's Mac on 5/7/18.
//  Copyright © 2018 Bhavik Barot. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <BHTextFieldManager/BHTextFieldManager.h>

@interface ViewController : UIViewController<UITextFieldDelegate,UITextViewDelegate,BHTextFieldManagerAccesoryViewDelegate>

@end

