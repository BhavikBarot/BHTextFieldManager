//
//  AppDelegate.h
//  BHTextFieldManagerDemo-ObjC
//
//  Created by Bhavik's Mac on 5/7/18.
//  Copyright © 2018 Bhavik Barot. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

