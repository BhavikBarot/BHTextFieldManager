//
//  ViewController.m
//  BHTextFieldManagerDemo-ObjC
//
//  Created by Bhavik's Mac on 5/7/18.
//  Copyright © 2018 Bhavik Barot. All rights reserved.
//

#import "ViewController.h"
#import "UITextView+Placeholder.h"

@interface ViewController ()
{
    BHTextFieldManager *BHFramework;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    textview.placeholder = @"TextView";
    textview.placeholderColor = [UIColor lightGrayColor];
    
    mainView1.layer.borderWidth = mainView2.layer.borderWidth = mainView3.layer.borderWidth = mainView4.layer.borderWidth = mainView5.layer.borderWidth = mainView6.layer.borderWidth = mainView7.layer.borderWidth = 1;
    
    mainView1.layer.cornerRadius = mainView2.layer.cornerRadius = mainView3.layer.cornerRadius = mainView4.layer.cornerRadius = mainView5.layer.cornerRadius = mainView6.layer.cornerRadius = mainView7.layer.cornerRadius = 5;
    
    mainView1.layer.borderColor = [UIColor redColor].CGColor;
    mainView2.layer.borderColor = [UIColor blueColor].CGColor;
    mainView3.layer.borderColor = [UIColor orangeColor].CGColor;
    mainView4.layer.borderColor = [UIColor greenColor].CGColor;
    mainView5.layer.borderColor = [UIColor cyanColor].CGColor;
    mainView6.layer.borderColor = [UIColor purpleColor].CGColor;
    mainView7.layer.borderColor = [UIColor magentaColor].CGColor;
    
    
    //Setup the BHTextFieldManager.
    BHFramework = [[BHTextFieldManager alloc] init];
    BHFramework.delegate = self;
    [BHFramework setEnable:self.view];
    [BHFramework setKeyboardDistanceFromTextField:20.f];
}

//TODO: BHTextFieldManagerDelegate Methods
-(void)upKeyBoardBtn:(id)sender isLastTextFieldOrTextView:(enum senderIDType)type {
    //Do Something...
    if (type == TextField) {
        NSLog(@"Sender(UITextField)'s First Responder is Resign, and Up Button Clicked");
    }
    else {
        NSLog(@"Sender(UITextView)'s First Responder is Resign, and Up Button Clicked");
    }
}
-(void)downKeyBoardBtn:(id)sender isLastTextFieldOrTextView:(enum senderIDType)type {
    switch (type) {
        case TextField:
            NSLog(@"Sender(UITextField)'s First Responder is Resign, and Down Button Clicked");
            break;
        case TextView:
            NSLog(@"Sender(UITextView)'s First Responder is Resign, and Down Button Clicked");
            break;
    }
}
-(void)doneKeyBoardBtn:(id)sender isLastTextFieldOrTextView:(enum senderIDType)type {
    //Do Something...
    NSLog(@"Sender's First Responder is Resign, and Done Button Clicked");
}

//Error Showing Method
-(void)isErrorOrNot:(BOOL)isError withError:(NSString *)error {
    //You will get the error here and you can pull/comment to me on github.
    NSLog(@"Error: %@",error);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
