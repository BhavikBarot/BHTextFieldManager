//
//  ViewController.m
//  BHTextFieldManagerDemo-ObjC
//
//  Created by Bhavik's Mac on 5/7/18.
//  Copyright © 2018 Bhavik Barot. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    BHTextFieldManagerAccesoryView *BHFramework;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //Setup the BHTextFieldManager.
    BHFramework = [[BHTextFieldManagerAccesoryView alloc] init];
    BHFramework.delegate = self;
    [BHFramework setEnable:self.view];
    [BHFramework setKeyboardDistanceFromTextField:20.f];
}
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    textField.inputAccessoryView = [BHFramework setInputViewForKeyboard:textField];
}
-(BOOL)textViewShouldBeginEditing:(UITextView *)textView {
    textView.inputAccessoryView = [BHFramework setInputViewForKeyboard:textView];
    return YES;
}

//TODO: BHTextFieldManagerAccesoryViewDelegate Methods
-(void)upKeyBoardBtn:(id)sender {
    //Do Something...
    NSLog(@"Sender's First Responder is Resign, and Up Button Clicked");
}
-(void)downKeyBoardBtn:(id)sender {
    //Do Something...
    NSLog(@"Sender's First Responder is Resign, and Down Button Clicked");
}
-(void)doneKeyBoardBtn:(id)sender {
    //Do Something...
    NSLog(@"Sender's First Responder is Resign, and Done Button Clicked");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
