//
//  BHTextFieldManager.h
//  BHTextFieldManager
//
//  Created by Bhavik's Mac on 3/8/18.
//  Copyright © 2018 Bhavik Barot. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BHTextFieldManager.
FOUNDATION_EXPORT double BHTextFieldManagerVersionNumber;

//! Project version string for BHTextFieldManager.
FOUNDATION_EXPORT const unsigned char BHTextFieldManagerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BHTextFieldManager/PublicHeader.h>

#import<BHTextFieldManager/BHTextFieldManager+Accesory.h>

