//
//  Bridging-Header.h
//  BHTextFieldManagerDemo-Swift
//
//  Created by Bhavik's Mac on 5/7/18.
//  Copyright © 2018 Bhavik Barot. All rights reserved.
//

#ifndef Bridging_Header_h
#define Bridging_Header_h


#endif /* Bridging_Header_h */

//#import <BHTextFieldManager/BHTextFieldManager.h>
#import "UITextView+Placeholder.h"
