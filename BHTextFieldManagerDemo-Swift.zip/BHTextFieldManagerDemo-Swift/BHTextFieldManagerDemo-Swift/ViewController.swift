//
//  ViewController.swift
//  BHTextFieldManagerDemo-Swift
//
//  Created by Bhavik's Mac on 5/7/18.
//  Copyright © 2018 Bhavik Barot. All rights reserved.
//

import UIKit
import BHTextFieldManager

class ViewController: UIViewController ,UITextFieldDelegate ,UITextViewDelegate ,BHTextFieldManagerDelegate{

    @IBOutlet var mainView1: UIView!
    @IBOutlet var mainView2: UIView!
    @IBOutlet var mainView3: UIView!
    @IBOutlet var mainView4: UIView!
    @IBOutlet var mainView5: UIView!
    @IBOutlet var mainView6: UIView!
    @IBOutlet var mainView7: UIView!
    
    var BHFramework = BHTextFieldManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        mainView1.layer.cornerRadius = 5
        mainView2.layer.cornerRadius = 5
        mainView3.layer.cornerRadius = 5
        mainView4.layer.cornerRadius = 5
        mainView5.layer.cornerRadius = 5
        mainView6.layer.cornerRadius = 5
        mainView7.layer.cornerRadius = 5
        
        mainView1.layer.borderWidth = 1
        mainView2.layer.borderWidth = 1
        mainView3.layer.borderWidth = 1
        mainView4.layer.borderWidth = 1
        mainView5.layer.borderWidth = 1
        mainView6.layer.borderWidth = 1
        mainView7.layer.borderWidth = 1
        
        mainView1.layer.borderColor = UIColor.red.cgColor;
        mainView2.layer.borderColor = UIColor.blue.cgColor;
        mainView3.layer.borderColor = UIColor.orange.cgColor;
        mainView4.layer.borderColor = UIColor.green.cgColor;
        mainView5.layer.borderColor = UIColor.cyan.cgColor;
        mainView6.layer.borderColor = UIColor.purple.cgColor;
        mainView7.layer.borderColor = UIColor.magenta.cgColor;
        
        //Setup the BHTextFieldManager.
        BHFramework.delegate = self
        BHFramework.setEnable(self.view)
        BHFramework.setKeyboardDistanceFromTextField(20)
    }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.inputAccessoryView = BHFramework.setInputViewForKeyboard(textField)
    }
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        textView.inputAccessoryView = BHFramework.setInputViewForKeyboard(textView)
        return true
    }
    
    //TODO: BHTextFieldManagerDelegate Methods
    func upKeyBoardBtn(_ sender: Any!) {
        print("Sender's First Responder is Resign, and Up Button Clicked")
    }
    func downKeyBoardBtn(_ sender: Any!) {
        print("Sender's First Responder is Resign, and Down Button Clicked")
    }
    func doneKeyBoardBtn(_ sender: Any!) {
        print("Sender's First Responder is Resign, and Done Button Clicked")
    }
    //Error Showing Method
    func isErrorOrNot(_ isError: Bool, withError error: String?) {
        //You will get the error here and you can pull/comment to me on github.
        print("Error: \(error ?? "Error")")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

