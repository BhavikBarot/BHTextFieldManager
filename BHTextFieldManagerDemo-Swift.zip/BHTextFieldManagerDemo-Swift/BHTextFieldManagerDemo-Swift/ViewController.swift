//
//  ViewController.swift
//  BHTextFieldManagerDemo-Swift
//
//  Created by Bhavik's Mac on 5/7/18.
//  Copyright © 2018 Bhavik Barot. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UITextFieldDelegate ,UITextViewDelegate ,BHTextFieldManagerAccesoryViewDelegate{

    var BHFramework = BHTextFieldManagerAccesoryView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Setup the BHTextFieldManager.
        BHFramework.delegate = self
        BHFramework.setEnable(self.view)
        BHFramework.setKeyboardDistanceFromTextField(20)
    }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.inputAccessoryView = BHFramework.setInputViewForKeyboard(textField)
    }
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        textView.inputAccessoryView = BHFramework.setInputViewForKeyboard(textView)
        return true
    }
    
    //TODO: BHTextFieldManagerAccesoryViewDelegate Methods
    func upKeyBoardBtn(_ sender: Any!) {
        print("Sender's First Responder is Resign, and Up Button Clicked")
    }
    func downKeyBoardBtn(_ sender: Any!) {
        print("Sender's First Responder is Resign, and Down Button Clicked")
    }
    func doneKeyBoardBtn(_ sender: Any!) {
        print("Sender's First Responder is Resign, and Done Button Clicked")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

